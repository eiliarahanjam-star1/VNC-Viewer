package com.example.vncviewer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class VncCanvas(
    private val sendPointer: (x: Int, y: Int, buttons: Int) -> Unit
) : View {
    private var bitmap: Bitmap? = null
    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    constructor(sendPointer: (Int, Int, Int) -> Unit, dummy: Boolean = true) : this(sendPointer)

    fun setBitmap(b: Bitmap) {
        bitmap = b
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = bitmap ?: return
        val sx = width.toFloat() / b.width
        val sy = height.toFloat() / b.height
        scale = min(sx, sy)
        val w = b.width * scale
        val h = b.height * scale
        offsetX = (width - w) / 2f
        offsetY = (height - h) / 2f
        val m = Matrix()
        m.setScale(scale, scale)
        m.postTranslate(offsetX, offsetY)
        canvas.drawBitmap(b, m, null)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val b = bitmap ?: return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y; dragging = true
                send(0x01, e.x, e.y, b)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) send(0x01, e.x, e.y, b)
                return true
            }
            MotionEvent.ACTION_UP -> {
                send(0x00, e.x, e.y, b)
                dragging = false
                return true
            }
        }
        return true
    }

    private fun send(buttons: Int, sx: Float, sy: Float, b: Bitmap) {
        val x = ((sx - offsetX) / max(scale, 0.001f)).toInt().coerceIn(0, b.width - 1)
        val y = ((sy - offsetY) / max(scale, 0.001f)).toInt().coerceIn(0, b.height - 1)
        sendPointer(x, y, buttons)
    }
}
