package com.example.vncviewer

import android.graphics.Bitmap
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Socket
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

class VncClient(
    private val host: String,
    private val port: Int,
    private val password: String,
    private val onStatus: (String) -> Unit,
    private val onFrame: (Bitmap) -> Unit
) {
    private var socket: Socket? = null
    private var input: DataInputStream? = null
    private var output: DataOutputStream? = null
    private var width = 0
    private var height = 0
    private lateinit var framebuffer: IntArray
    @Volatile private var closed = false
    private var negotiatedMinorVersion = 8

    fun run() {
        socket = Socket(host, port).also {
            it.tcpNoDelay = true
            it.soTimeout = 0
        }
        input = DataInputStream(BufferedInputStream(socket!!.getInputStream()))
        output = DataOutputStream(BufferedOutputStream(socket!!.getOutputStream()))

        // The socket and streams must exist before reading the server banner.
        val serverVersion = readAscii(12)
        onStatus("VNC server version: ${serverVersion.trim()}")

        val versionMatch = Regex("""RFB (\d{3})\.(\d{3})""").find(serverVersion)
            ?: throw IOException("Invalid VNC server version: ${serverVersion.trim()}")
        val major = versionMatch.groupValues[1].toInt()
        val serverMinor = versionMatch.groupValues[2].toInt()
	val clientMinor = when {
    	major > 3 -> 8
    	serverMinor >= 8 -> 8
    	serverMinor >= 7 -> 7
    	else -> 3
	}
	negotiatedMinorVersion = clientMinor
        writeAscii("RFB 003.${clientMinor.toString().padStart(3, '0')}\n")

        negotiateSecurity(clientMinor, serverVersion)

        // ClientInit: shared = 1
        output!!.writeByte(1)
        output!!.flush()

        width = input!!.readUnsignedShort()
        height = input!!.readUnsignedShort()
        if (width <= 0 || height <= 0 || width.toLong() * height > 16_777_216L) {
            throw IOException("Invalid VNC framebuffer size: ${width}x$height")
        }
        framebuffer = IntArray(width * height)

        // ServerInit: pixel format (16 bytes), followed by desktop-name length.
        skipFully(16)
        val nameLen = input!!.readInt()
        if (nameLen < 0 || nameLen > 1_048_576) {
            throw IOException("Invalid VNC desktop-name length: $nameLen")
        }
        if (nameLen > 0) skipFully(nameLen)

        // SetPixelFormat: 32 bpp, depth 24, true color, RGB shifts 16/8/0.
        output!!.writeByte(0)
        output!!.writeByte(0)
        output!!.writeByte(0)
        output!!.writeByte(0)
        output!!.writeByte(32)
        output!!.writeByte(24)
        output!!.writeByte(0)
        output!!.writeByte(1)
        output!!.writeShort(255)
        output!!.writeShort(255)
        output!!.writeShort(255)
        output!!.writeByte(16)
        output!!.writeByte(8)
        output!!.writeByte(0)
        output!!.writeByte(0)
        output!!.writeByte(0)
        output!!.writeByte(0)
        output!!.flush()

        // Encodings: RAW (0), CopyRect (1).
        output!!.writeByte(2)
        output!!.writeInt(0)
        output!!.writeInt(1)
        output!!.flush()

        onStatus("Connected: ${width}x$height")
        requestUpdate(false, 0, 0, width, height)

        while (!closed) {
            val type = input!!.readUnsignedByte()
            when (type) {
                0 -> readFramebufferUpdate()
                2 -> { /* Bell */ }
                3 -> readServerCutText()
                else -> throw IOException("Unsupported VNC message: $type")
            }
        }
    }

    private fun negotiateSecurity(clientMinor: Int, serverVersion: String) {
        if (clientMinor == 3) {
            // RFB 3.3 uses a 32-bit security type instead of a type list.
            val securityType = input!!.readInt()
            when (securityType) {
                0 -> throw IOException(readFailureReason("VNC server rejected connection"))
                1 -> return // None security in RFB 3.3 has no SecurityResult.
                2 -> {
                    doVncAuth()
                    return
                }
                else -> throw IOException(
                    "Unsupported security type: $securityType; server=${serverVersion.trim()}"
                )
            }
        }

        // RFB 3.7/3.8: one-byte count followed by the offered security types.
        val count = input!!.readUnsignedByte()
        if (count == 0) {
            throw IOException(readFailureReason("VNC server offered no security types"))
        }

        val types = ByteArray(count)
        input!!.readFully(types)
        val offeredTypes = types.map { it.toInt() and 0xff }
        val selected = when {
            2 in offeredTypes -> 2 // Prefer standard VNC password authentication.
            1 in offeredTypes -> 1 // None, only if the server offers it.
            else -> throw IOException(
                "No supported VNC security type. Offered=$offeredTypes; " +
                    "server=${serverVersion.trim()}"
            )
        }

        output!!.writeByte(selected)
        output!!.flush()

        if (selected == 2) {
            doVncAuth()
        } else if (selected == 1 && clientMinor >= 8) {
            // RFB 3.8 requires SecurityResult even when None is selected.
            val result = input!!.readInt()
            if (result != 0) {
                throw IOException(readFailureReason("VNC None-security handshake failed"))
            }
        }
    }

    private fun readFailureReason(defaultMessage: String): String {
        return try {
            val len = input!!.readInt()
            if (len < 0 || len > 65536) {
                "$defaultMessage (invalid reason length: $len)"
            } else {
                val reason = readAscii(len)
                if (reason.isBlank()) "$defaultMessage (server sent an empty reason)" else reason
            }
        } catch (e: Exception) {
            "$defaultMessage (could not read server reason: ${e.message ?: e.javaClass.simpleName})"
        }
    }

    private fun doVncAuth() {
        val challenge = ByteArray(16)
        input!!.readFully(challenge)

        // Standard VNC authentication uses the first 8 password bytes,
        // with the bits in each byte reversed, as the DES key.
        val key = ByteArray(8)
        val pw = password.toByteArray(Charsets.ISO_8859_1)
        for (i in 0 until 8) {
            key[i] = if (i < pw.size) reverseBits(pw[i]) else 0
        }

        val cipher = Cipher.getInstance("DES/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "DES"))
        output!!.write(cipher.doFinal(challenge))
        output!!.flush()

        val result = input!!.readInt()
        if (result != 0) {
            val reason = if (negotiatedMinorVersion >= 8) {
                readFailureReason("VNC authentication failed")
            } else {
                "VNC authentication failed (result=$result)"
            }
            throw IOException(reason)
        }
    }

    private fun reverseBits(b: Byte): Byte {
        var x = b.toInt() and 0xff
        var r = 0
        repeat(8) {
            r = (r shl 1) or (x and 1)
            x = x shr 1
        }
        return r.toByte()
    }

    private fun readFramebufferUpdate() {
        input!!.readUnsignedByte() // padding
        val count = input!!.readUnsignedShort()
        repeat(count) {
            val x = input!!.readUnsignedShort()
            val y = input!!.readUnsignedShort()
            val w = input!!.readUnsignedShort()
            val h = input!!.readUnsignedShort()
            val encoding = input!!.readInt()

            when (encoding) {
                0 -> readRaw(x, y, w, h)
                1 -> readCopyRect(x, y, w, h)
                else -> throw IOException("Unsupported VNC encoding: $encoding")
            }
        }
        onFrame(Bitmap.createBitmap(framebuffer, width, height, Bitmap.Config.ARGB_8888))
        requestUpdate(true, 0, 0, width, height)
    }

    private fun readRaw(x: Int, y: Int, w: Int, h: Int) {
        val row = ByteArray(w * 4)
        for (yy in 0 until h) {
            input!!.readFully(row)
            var off = 0
            for (xx in 0 until w) {
                val b = row[off].toInt() and 0xff
                val g = row[off + 1].toInt() and 0xff
                val r = row[off + 2].toInt() and 0xff
                if (x + xx < width && y + yy < height) {
                    framebuffer[(y + yy) * width + x + xx] =
                        (0xff shl 24) or (r shl 16) or (g shl 8) or b
                }
                off += 4
            }
        }
    }

    private fun readCopyRect(x: Int, y: Int, w: Int, h: Int) {
        val srcX = input!!.readUnsignedShort()
        val srcY = input!!.readUnsignedShort()
        val temp = IntArray(w * h)

        for (yy in 0 until h) {
            for (xx in 0 until w) {
                temp[yy * w + xx] = framebuffer[(srcY + yy) * width + srcX + xx]
            }
        }
        for (yy in 0 until h) {
            for (xx in 0 until w) {
                framebuffer[(y + yy) * width + x + xx] = temp[yy * w + xx]
            }
        }
    }

    private fun requestUpdate(incremental: Boolean, x: Int, y: Int, w: Int, h: Int) {
        output!!.writeByte(3)
        output!!.writeByte(if (incremental) 1 else 0)
        output!!.writeShort(x)
        output!!.writeShort(y)
        output!!.writeShort(w)
        output!!.writeShort(h)
        output!!.flush()
    }

    fun pointerEvent(x: Int, y: Int, buttons: Int) {
        synchronized(this) {
            try {
                output?.writeByte(5)
                output?.writeByte(buttons)
                output?.writeShort(x)
                output?.writeShort(y)
                output?.flush()
            } catch (_: IOException) {
                // The connection may have closed while an event was being sent.
            }
        }
    }

    private fun readServerCutText() {
        skipFully(3)
        val len = input!!.readInt()
        if (len < 0 || len > 1_048_576) {
            throw IOException("Invalid VNC clipboard text length: $len")
        }
        if (len > 0) skipFully(len)
    }

    fun close() {
        closed = true
        try {
            socket?.close()
        } catch (_: Exception) {
            // Ignore close errors.
        }
    }

    private fun readAscii(n: Int): String {
        val bytes = ByteArray(n)
        input!!.readFully(bytes)
        return String(bytes, Charsets.US_ASCII)
    }

    private fun writeAscii(value: String) {
        output!!.write(value.toByteArray(Charsets.US_ASCII))
        output!!.flush()
    }

    private fun skipFully(n: Int) {
        var left = n
        while (left > 0) {
            val skipped = input!!.skipBytes(left)
            if (skipped <= 0) {
                input!!.readByte()
                left--
            } else {
                left -= skipped
            }
        }
    }
}
