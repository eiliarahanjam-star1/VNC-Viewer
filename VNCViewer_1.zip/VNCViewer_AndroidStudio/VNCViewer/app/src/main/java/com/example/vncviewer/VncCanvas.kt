
package com.example.vncviewer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class VncCanvas(
    context: Context,
    private val sendPointer: (x: Int, y: Int, buttons: Int) -> Unit
) : View(context) {

    private var bitmap: Bitmap? = null
    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var dragging = false

    fun setBitmap(b: Bitmap) {
        bitmap = b
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val b = bitmap ?: return
        if (b.width <= 0 || b.height <= 0 || width <= 0 || height <= 0) return

        val sx = width.toFloat() / b.width
        val sy = height.toFloat() / b.height

        scale = min(sx, sy)

        val w = b.width * scale
        val h = b.height * scale

        offsetX = (width - w) / 2f
        offsetY = (height - h) / 2f

        val matrix = Matrix().apply {
            setScale(scale, scale)
            postTranslate(offsetX, offsetY)
        }

        canvas.drawBitmap(b, matrix, null)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val b = bitmap ?: return true

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                sendPointerCoordinates(0x01, event.x, event.y, b)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    sendPointerCoordinates(0x01, event.x, event.y, b)
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                sendPointerCoordinates(0x00, event.x, event.y, b)
                dragging = false
                performClick()
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    sendPointerCoordinates(0x00, event.x, event.y, b)
                }
                dragging = false
                return true
            }
        }

        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun sendPointerCoordinates(
        buttons: Int,
        screenX: Float,
        screenY: Float,
        b: Bitmap
    ) {
        val x = ((screenX - offsetX) / max(scale, 0.001f))
            .toInt()
            .coerceIn(0, b.width - 1)

        val y = ((screenY - offsetY) / max(scale, 0.001f))
            .toInt()
            .coerceIn(0, b.height - 1)

        sendPointer(x, y, buttons)
    }
}
