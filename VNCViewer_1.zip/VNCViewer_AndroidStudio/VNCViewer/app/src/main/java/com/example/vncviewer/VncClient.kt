package com.example.vncviewer

import android.graphics.Bitmap
import java.io.*
import java.net.Socket
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

class VncClient(
    private val host: String,
    private val port: Int,
    private val password: String,
    private val onStatus: (String) -> Unit,
    private val onFrame: (Bitmap) -> Unit
) {
    private var socket: Socket? = null
    private var input: DataInputStream? = null
    private var output: DataOutputStream? = null
    private var width = 0
    private var height = 0
    private lateinit var framebuffer: IntArray
    private var closed = false

    fun run() {
        socket = Socket(host, port).also { it.tcpNoDelay = true; it.soTimeout = 0 }
        input = DataInputStream(BufferedInputStream(socket!!.getInputStream()))
        output = DataOutputStream(BufferedOutputStream(socket!!.getOutputStream()))

        val serverVersion = readAscii(12)
        val clientVersion = when {
            serverVersion.contains("003.008") -> "RFB 003.008\n"
            serverVersion.contains("003.007") -> "RFB 003.007\n"
            else -> "RFB 003.003\n"
        }
        writeAscii(clientVersion)

        negotiateSecurity(serverVersion)

        // ClientInit: shared = 1
        output!!.writeByte(1)
        output!!.flush()

        width = input!!.readUnsignedShort()
        height = input!!.readUnsignedShort()
        framebuffer = IntArray(width * height)

        // ServerInit remaining fields
        input!!.skipBytes(16) // pixel format
        val nameLen = input!!.readInt()
        if (nameLen > 0) skipFully(nameLen)

        // SetPixelFormat: 32 bpp, depth 24, true color, RGB shifts 16/8/0
        output!!.writeByte(0)
        output!!.writeByte(0); output!!.writeByte(0); output!!.writeByte(0)
        output!!.writeByte(32)
        output!!.writeByte(24)
        output!!.writeByte(0)
        output!!.writeByte(1)
        output!!.writeShort(255)
        output!!.writeShort(255)
        output!!.writeShort(255)
        output!!.writeByte(16)
        output!!.writeByte(8)
        output!!.writeByte(0)
        output!!.writeByte(0); output!!.writeByte(0); output!!.writeByte(0)
        output!!.flush()

        // Encodings: RAW(0), CopyRect(1)
        output!!.writeByte(2)
        output!!.writeInt(0)
        output!!.writeInt(1)
        output!!.flush()

        onStatus("Connected: ${width}x$height")
        requestUpdate(false, 0, 0, width, height)

        while (!closed) {
            val type = input!!.readUnsignedByte()
            when (type) {
                0 -> readFramebufferUpdate()
                2 -> { /* Bell */ }
                3 -> readServerCutText()
                else -> throw IOException("Unsupported VNC message: $type")
            }
        }
    }

    private fun negotiateSecurity(serverVersion: String) {
        if (serverVersion.contains("003.003")) {
            val sec = input!!.readInt()
            if (sec == 1) return
            if (sec == 2) { doVncAuth(); return }
            throw IOException("Unsupported security type: $sec")
        }

        val count = input!!.readUnsignedByte()
        if (count == 0) {
            val len = input!!.readUnsignedByte()
            throw IOException("VNC security failed: ${readAscii(len)}")
        }
        val types = ByteArray(count)
        input!!.readFully(types)
        val selected = if (types.any { (it.toInt() and 0xff) == 2 }) 2
                       else if (types.any { (it.toInt() and 0xff) == 1 }) 1
                       else throw IOException("No supported VNC security type")
        output!!.writeByte(selected)
        output!!.flush()
        if (selected == 2) doVncAuth()
        if (selected == 1) {
            val result = input!!.readInt()
            if (result != 0) throw IOException("VNC authentication failed")
        }
    }

    private fun doVncAuth() {
        val challenge = ByteArray(16)
        input!!.readFully(challenge)
        val key = ByteArray(8)
        val pw = password.toByteArray(Charsets.ISO_8859_1)
        for (i in 0 until 8) key[i] = if (i < pw.size) reverseBits(pw[i]) else 0
        val cipher = Cipher.getInstance("DES/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "DES"))
        val response = cipher.doFinal(challenge)
        output!!.write(response)
        output!!.flush()
        val result = input!!.readInt()
        if (result != 0) throw IOException("VNC authentication failed")
    }

    private fun reverseBits(b: Byte): Byte {
        var x = b.toInt() and 0xff
        var r = 0
        repeat(8) { r = (r shl 1) or (x and 1); x = x shr 1 }
        return r.toByte()
    }

    private fun readFramebufferUpdate() {
        input!!.readUnsignedByte() // padding
        val n = input!!.readUnsignedShort()
        repeat(n) {
            val x = input!!.readUnsignedShort()
            val y = input!!.readUnsignedShort()
            val w = input!!.readUnsignedShort()
            val h = input!!.readUnsignedShort()
            val encoding = input!!.readInt()
            when (encoding) {
                0 -> readRaw(x, y, w, h)
                1 -> readCopyRect(x, y, w, h)
                else -> throw IOException("Unsupported encoding: $encoding")
            }
        }
        onFrame(Bitmap.createBitmap(framebuffer, width, height, Bitmap.Config.ARGB_8888))
        requestUpdate(true, 0, 0, width, height)
    }

    private fun readRaw(x: Int, y: Int, w: Int, h: Int) {
        val row = ByteArray(w * 4)
        for (yy in 0 until h) {
            input!!.readFully(row)
            var off = 0
            for (xx in 0 until w) {
                val b = row[off].toInt() and 255
                val g = row[off + 1].toInt() and 255
                val r = row[off + 2].toInt() and 255
                framebuffer[(y + yy) * width + x + xx] =
                    (0xff shl 24) or (r shl 16) or (g shl 8) or b
                off += 4
            }
        }
    }

    private fun readCopyRect(x: Int, y: Int, w: Int, h: Int) {
        val srcX = input!!.readUnsignedShort()
        val srcY = input!!.readUnsignedShort()
        val temp = IntArray(w * h)
        for (yy in 0 until h)
            for (xx in 0 until w)
                temp[yy * w + xx] = framebuffer[(srcY + yy) * width + srcX + xx]
        for (yy in 0 until h)
            for (xx in 0 until w)
                framebuffer[(y + yy) * width + x + xx] = temp[yy * w + xx]
    }

    private fun requestUpdate(incremental: Boolean, x: Int, y: Int, w: Int, h: Int) {
        output!!.writeByte(3)
        output!!.writeByte(if (incremental) 1 else 0)
        output!!.writeShort(x); output!!.writeShort(y)
        output!!.writeShort(w); output!!.writeShort(h)
        output!!.flush()
    }

    fun pointerEvent(x: Int, y: Int, buttons: Int) {
        synchronized(this) {
            try {
                output?.writeByte(5)
                output?.writeByte(buttons)
                output?.writeShort(x)
                output?.writeShort(y)
                output?.flush()
            } catch (_: IOException) {}
        }
    }

    private fun readServerCutText() {
        skipFully(3)
        val len = input!!.readInt()
        if (len > 0) skipFully(len)
    }

    fun close() {
        closed = true
        try { socket?.close() } catch (_: Exception) {}
    }

    private fun readAscii(n: Int): String {
        val b = ByteArray(n)
        input!!.readFully(b)
        return String(b, Charsets.US_ASCII)
    }

    private fun writeAscii(s: String) {
        output!!.write(s.toByteArray(Charsets.US_ASCII))
        output!!.flush()
    }

    private fun skipFully(n: Int) {
        var left = n
        while (left > 0) {
            val s = input!!.skipBytes(left)
            if (s <= 0) { input!!.readByte(); left-- } else left -= s
        }
    }
}
