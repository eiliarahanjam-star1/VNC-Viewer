package com.example.vncviewer

import android.app.Activity
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.widget.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var client: VncClient? = null
    private lateinit var status: TextView
    private lateinit var container: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val host = findViewById<EditText>(R.id.host)
        val port = findViewById<EditText>(R.id.port)
        val password = findViewById<EditText>(R.id.password)
        val connect = findViewById<Button>(R.id.connect)
        status = findViewById(R.id.status)
        container = findViewById(R.id.viewContainer)

        connect.setOnClickListener {
            if (client != null) {
                client?.close()
                client = null
                container.removeAllViews()
                container.visibility = View.GONE
                connect.text = "Connect"
                status.text = "Disconnected"
                return@setOnClickListener
            }

            val h = host.text.toString().trim()
            val p = port.text.toString().toIntOrNull() ?: 5900
            val pw = password.text.toString()
            if (h.isEmpty()) {
                Toast.makeText(this, "Enter IP address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            status.text = "Connecting..."
            connect.text = "Disconnect"
            executor.execute {
                try {
                    val c = VncClient(h, p, pw,
                        onStatus = { s -> runOnUiThread { status.text = s } },
                        onFrame = { bmp ->
                            runOnUiThread {
                                var v = container.getChildAt(0) as? VncCanvas
                                if (v == null) {
                                    v = VncCanvas { x, y, buttons ->
                                        client?.pointerEvent(x, y, buttons)
                                    }
                                    container.addView(v)
                                    container.visibility = View.VISIBLE
                                }
                                v.setBitmap(bmp)
                            }
                        }
                    )
                    client = c
                    c.run()
                } catch (t: Throwable) {
                    runOnUiThread {
                        status.text = "Error: ${t.message ?: "connection failed"}"
                        connect.text = "Connect"
                        client = null
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        client?.close()
        executor.shutdownNow()
        super.onDestroy()
    }
}
