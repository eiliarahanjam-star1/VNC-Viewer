# VNC Viewer for Android

یک VNC Viewer سبک برای شبکه داخلی، نوشته‌شده با Kotlin و مناسب Android Studio.

## قابلیت‌های نسخه 1.0
- RFB/VNC 3.3 / 3.7 / 3.8
- احراز هویت VNC Password (Security Type 2)
- بدون احراز هویت
- RAW و CopyRect
- نمایش framebuffer
- کلیک و Drag با لمس
- IP و Port قابل تنظیم
- مناسب شبکه LAN/Wi-Fi

## ساخت پروژه
1. Android Studio را باز کنید.
2. گزینه Open را بزنید و پوشه VNCViewer را انتخاب کنید.
3. صبر کنید Gradle Sync کامل شود.
4. Run را روی گوشی یا Emulator اجرا کنید.

## نکته مهم
این پروژه برای VNC Serverهای رایج در شبکه داخلی نوشته شده است. برای استفاده صنعتی، ابتدا روی VNC Server واقعی خودتان تست شود. برخی VNC Serverها از Encodingهای فشرده مثل Tight/ZRLE/Hextile یا ویژگی‌های خاص استفاده می‌کنند که در این نسخه پیاده‌سازی نشده‌اند.

Port پیش‌فرض: 5900
